#ifndef _BULLET_WORLD_

#include "ahmed_exp.h"

/* ----------------------------------------------------------------------------------- */

Ahmed_experiment::Ahmed_experiment(Parameters *params) : Experiment(params)
{
  int size = m_parameters->getNbAgentsPerGroup();
  inputs.resize(size);
  outputs.resize(size);

  ctrnn_input.resize(size);
  ctrnn_output.resize(size);

  m_robot_robot_distance.resize(size);

  ir_ray_length.resize(size);
#ifdef FLOOR_SENSORS
  floor_sensor_readings.resize(size);
#endif
  m_local_fitness.resize(size);

  int tot_num_sensors = m_irSensor->get_ir_num_sensors();
#ifdef SIMPLE_CAMERA
  tot_num_sensors += m_camera->get_num_pixel();
#endif
#ifdef FLOOR_SENSORS
  tot_num_sensors += m_floorSensor->get_num_floor_sensors();
#endif

  for (unsigned int r = 0; r < size; r++)
  {
    m_robot_robot_distance[r].assign(size, 0.0);
    m_pfsm.push_back(new Pfsm(r));

    if (m_pfsm[r]->get_num_input() /* m_networks[r]->get_num_input() */ != tot_num_sensors)
    {
      cerr
          << "In Ahmed_experiment - There is a difference between the number of sensors and the input of the robot copntroller"
          << endl;
      exit(EXIT_FAILURE);
    }
    else
      inputs[r].assign(tot_num_sensors, 0.0);

    if (m_pfsm[r]->get_num_output() /* m_networks[r]->get_num_output()*/ != 2)
    {
      cerr << "In Ahmed_experiment - The controller output must be 2 for the kinetic robot" << endl;
      exit(EXIT_FAILURE);
    }
    else
      outputs[r].assign(2, 0.0);

    ctrnn_input[r].assign(m_networks[r]->get_num_input(), 0.0);
    ctrnn_output[r].assign(m_networks[r]->get_num_output(), 0.0);

    ir_ray_length[r].assign(m_irSensor->get_ir_num_sensors(), m_irSensor->get_ir_dist_range());
#ifdef FLOOR_SENSORS
    floor_sensor_readings[r].assign(m_floorSensor->get_num_floor_sensors(), 0.0);
#endif
  }
  m_num_neighbours = 1;
  ListeningTime = 3;
  register_data_time = 50; // second
  Strategy = EA;           /* EA for Evolutionary Approach, VM for Voter model, and MM for majorty model */
  Comm_Distance = 0.5;     /* communication distance for the robots swarm, for the valentini approach it must be 0.5 */
  Median = 100;
  K_Neighbours = 3;
}

/* ----------------------------------------------------------------------------------- */

Ahmed_experiment::~Ahmed_experiment()
{
  m_pfsm.erase(m_pfsm.begin(), m_pfsm.begin() + m_pfsm.size());
  m_pfsm.clear();
}

/* ----------------------------------------------------------------------------------- */

void Ahmed_experiment::evaluate_solutions(void)
{
  init_evaluations_loop();
  do
  { // Loop for evaluations for single trial
    init_single_evaluation();
    do
    { // This is the loop for the iterations mean simulation steps
      adv();
    } while (stop_iterations_loop()); // Until the last iteration
                                      // for my work i need to compute the fitness here as average of agents fitness
  } while (stop_evaluations_loop());  // Until the last evaluation
}

/* ----------------------------------------------------------------------------------- */

void Ahmed_experiment::init_evaluations_loop()
{
  m_evaluation = 0;

  if (m_parameters->isModeEvaluation())
  {
    CountVec.clear(); // this vector hold the number of the robots eith right opinion
    avg_trajectory_length.clear();
    Data_Summary_White.clear();
    Data_Summary_Black.clear();
  }

  fill(m_fitness.begin(), m_fitness.end(), 0.0);

  if (m_parameters->isModeEvolution())
  { // Evolutionary mode only
    vector<chromosome_type> geneSet;
    for (int r = 0; r < m_parameters->getNbAgentsPerGroup(); r++)
    {
      if (m_parameters->AreGroupsHeteroGroups())
      {
        for (int j = 0; j < m_NbGenesPerInd; j++)
        {
          geneSet.push_back(m_genes[(r * m_NbGenesPerInd) + j]);
        }
        m_networks[r]->init(geneSet);
        geneSet.erase(geneSet.begin(), geneSet.begin() + geneSet.size());
        geneSet.clear();
      }
      else
      {
        m_networks[r]->init(m_genes);
      }
    }
  }
}

/* ----------------------------------------------------------------------------------- */

void Ahmed_experiment::init_single_evaluation(void)
{
  m_iteration = 0;
  if (m_parameters->isModeEvaluation())
  {
    CountofRightAgents = 0;
    min_size_index = -1;
    min_trjectory_size = 0;
    RandomFloor.clear();
    all_opinions.clear();
    all_positions.clear();
    AllCommunication.clear();
    vector<int> vec(m_parameters->getNbMaxIterations(), -1);
    vector<int> vec1;
    vector<double> vec2;
    for (int i = 0; i < m_agents.size(); i++)
    {
      all_opinions.push_back(vec);
      all_positions.push_back(vec1);
    }
    for (int i = 0; i < m_parameters->getNbMaxIterations(); i++)
    {
      AllCommunication.push_back(vec2);
    }
  }

  fill(m_local_fitness.begin(), m_local_fitness.end(), 0.0);

  for (int r = 0; r < m_agents.size(); r++)
  {

    // Reset the position of agent r
    set_agents_position(r);

    // reset the network
    m_networks[r]->reset();

    // reset input values to zero
    fill(inputs[r].begin(), inputs[r].end(), 0.0);
    fill(ctrnn_input[r].begin(), ctrnn_input[r].end(), 0.0);

    // reset output values to zero
    fill(outputs[r].begin(), outputs[r].end(), 0.0);
    fill(ctrnn_output[r].begin(), ctrnn_output[r].end(), 0.0);
  }

  // Here you define the type of environment
  if (m_evaluation % 2)
  {
    floor_type = WHITE_DOMINANT;
  }
  else
  {
    floor_type = BLACK_DOMINANT;
  }
  if (Strategy != EA)
  {
    Initial_Hand_Coded_Model();
  }
}

/* ----------------------------------------------------------------------------------- */

void Ahmed_experiment::set_agents_position(int r)
{
  double min_dist = 0.008;
  bool flag = false;
  double x, y;

  vector<double> init_agents_pos;
  vector<double> init_agents_rot;
  vector<double> init_agents_vel;

  init_agents_pos.assign(3, 0.0);
  init_agents_rot.assign(3, 0.0);
  init_agents_vel.assign(3, 0.0);
  ///////////////////////////////////////////////////////////////////////////////////////
  do
  {
    flag = false;
    x = gsl_rng_uniform_pos(GSL_randon_generator::r_rand) * (m_objects[0]->get_dim()[0] - 0.2) + 0.1; // This is the arena length
    y = gsl_rng_uniform_pos(GSL_randon_generator::r_rand) * (m_objects[0]->get_dim()[0] - 0.2) + 0.1;

    int ar = 0;
    while (ar < r)
    {
      double x_dist = (x - m_agents[ar]->get_pos()[0]);
      double y_dist = (y - m_agents[ar]->get_pos()[1]);
      double distance = (x_dist * x_dist) + (y_dist * y_dist);
      if (distance < min_dist)
      {
        flag = true;
        break;
      }
      ++ar;
    }
  } while (flag);

  init_agents_pos[0] = x;
  init_agents_pos[1] = y;
  init_agents_rot[2] = gsl_rng_uniform_pos(GSL_randon_generator::r_rand) * TWO_PI;
  if (init_agents_rot[2] < 0.0)
    init_agents_rot[2] += TWO_PI;
  else if (init_agents_rot[2] > TWO_PI)
    init_agents_rot[2] -= TWO_PI;

  // Robot init position
  m_agents[r]->set_pos(init_agents_pos);
  // Robot init orientation
  m_agents[r]->set_rot(init_agents_rot);
  // Robot init velocity
  m_agents[r]->set_vel(init_agents_vel);
}

/* ----------------------------------------------------------------------------------- */

void Ahmed_experiment::adv(void)
{
  if (m_parameters->isModeViewing())
    stop_iterations_loop();

  update_sensors();

  update_controllers();

  update_actuators();

  update_world();

#ifdef WITH_COLLISION_CHECK
  // manage_collisions_without_repositioning ( );
  // manage_collisions_with_repositioning ( );
#endif
  compute_fitness();

  m_iteration++;
}

/* ----------------------------------------------------------------------------------- */

void Ahmed_experiment::update_sensors(void)
{

  // Reset the array to store the ir and floor sensors readings
  for (int r = 0; r < m_agents.size(); r++)
  {
    fill(ir_ray_length[r].begin(), ir_ray_length[r].end(), m_irSensor->get_ir_dist_range());
#ifdef FLOOR_SENSORS
    fill(floor_sensor_readings[r].begin(), floor_sensor_readings[r].end(), 0.0);
#endif
  }

#ifdef SIMPLE_CAMERA
  // init and reset the array to store camera pixels value
  std::vector<double> pixel;
  pixel.assign(m_camera->get_num_pixel(), 0.0);
#endif

  for (int r = 0; r < m_agents.size(); r++)
  {

    ////////////////////////////////////////////////////////////////
    int count_inputs = 0;
    int count_ctrnn_inputs = -1;
    int tile_number = -1;
#ifdef SIMPLE_CAMERA
    /* ############################################################ */
    // Reset camera pixels readings
    m_camera->reset_camera();
    /* ############################################################ */
#endif

    /* ############################################################ */
    // Update ir ray tracing wrt other agents
    if (r < (m_agents.size() - 1))
    {
      for (int t = r + 1; t < m_agents.size(); t++)
      {
        m_robot_robot_distance[r][t] = m_irSensor->agent_agent_readings(m_agents[r], m_agents[t], ir_ray_length[r], ir_ray_length[t]);
        m_robot_robot_distance[t][r] = m_robot_robot_distance[r][t];
      }
    }

#ifdef SIMPLE_CAMERA
    /* ############################################################ */
    // Update camera pixels wrt other agents
    for (int t = 0; t < m_agents.size(); t++)
      if (t != r)
        m_camera->update_pixel_rgb_values(m_agents[r], m_agents[t]);
        /* ############################################################ */
#endif

    /* ############################################################ */
    // Update ir ray tracing wrt objects
    for (int obj = 0; obj < m_parameters->getNbObjects(); obj++)
    {
      // Update ir_readings wrt objects
      if (m_objects[obj]->get_type_id() == BRICK)
      {
        m_irSensor->agent_brick_readings(m_agents[r],
                                         m_objects[obj], ir_ray_length[r]);
      }
      else
        m_irSensor->agent_round_obj_readings(m_agents[r],
                                             m_objects[obj], ir_ray_length[r]);

#ifdef SIMPLE_CAMERA
        // Update camera pixels wrt objects ( Does the camera see objects? if YES, uncomment line below )
        // m_camera->update_pixel_rgb_values( m_agents[r], m_objects[obj] );
#endif
    }
    /* ############################################################ */

    /* ############################################################ */
    // COMPUTE IR READINGS, add noise and normalise in [0, 1] the readings
    m_irSensor->add_noise(ir_ray_length[r], inputs[r], &count_inputs);
    /* ############################################################ */

#ifdef SIMPLE_CAMERA
    /* ############################################################ */
    m_camera->merge_camera_pixels_view(); // Merge CAMERA PIXELS * 3 (RGB)
    // For the 3 front RGB camera, we put in inputs color that we want to detect
    // 0 means no object with this color in front of you
    // 1 means an object with this color in front of you
    for (int p = 0; p < m_camera->get_num_pixel(); p++)
    {
      m_camera->get_pixel_rgb(pixel, p);
      // cerr << " III pix0= " << pixel[0] << " pix1= " << pixel[1] << " pix2= " << pixel[2] << endl;
      //  Color that robots will see
      if (p == 0)
        inputs[r][++count_inputs] = pixel[0];
      else if (p == 1)
        inputs[r][++count_inputs] = pixel[0];
      else if (p == 2)
        inputs[r][++count_inputs] = pixel[0];
    }
#endif

    /* ############################################################ */
    // new captured opinion
#ifdef FLOOR_SENSORS
    m_floorSensor->agent_floor_sensor_readings(m_agents[r], m_objects[0], floor_sensor_readings[r], floor_type, tile_number);
    m_floorSensor->add_noise(floor_sensor_readings[r], ctrnn_input[r], &count_ctrnn_inputs);
#endif

    /* ############################################################ */
    // This is all about communication
    if (Strategy == EA)
    {
      vector<pair<double, int>> dist_vect;
      for (int t = 0; t < m_agents.size(); t++)
      {
        if (t != r)
          dist_vect.push_back(make_pair(m_robot_robot_distance[r][t] + gsl_rng_uniform(GSL_randon_generator::r_rand) * 0.2 - 0.1, t)); //
      }
      sort(dist_vect.begin(), dist_vect.end());

      /* -------------------------------------------------------------------------------- */
      /* -------------------choosing closest neighbor only------------------------------- */
      /* -------------------------------------------------------------------------------- */
      // neighbour(s) opinion
      for (int f = 0; f < m_num_neighbours; f++)
      {
        if (dist_vect[f].first <= Comm_Distance)
        {
          if (ctrnn_output[dist_vect[f].second][0] > 0.5)
          {
            ctrnn_input[r][++count_ctrnn_inputs] = 1;
          }
          else
          {
            ctrnn_input[r][++count_ctrnn_inputs] = 0;
          }
        }
        else
        {
          ctrnn_input[r][++count_ctrnn_inputs] = 0.5;
        }
        dist_vect.erase(dist_vect.begin(), dist_vect.begin() + dist_vect.size());
        dist_vect.clear();
      }
    }
  }
}

/* ----------------------------------------------------------------------------------- */

void Ahmed_experiment::update_controllers(void)
{
  vector<double> colour;

  for (int r = 0; r < m_agents.size(); r++)
  {
    m_pfsm[r]->step(inputs[r], outputs[r]);
    if (Strategy == EA)
    {
      m_networks[r]->step(ctrnn_input[r], ctrnn_output[r]);
    }
    else
    {
      if (m_agents[r]->Agent_State == EXPLORATION)
        Exploration(r);
      else if (m_agents[r]->Agent_State == DISSEMINATION)
        Dissemination(r);
      else if (m_agents[r]->Agent_State == ESTIMATION)
        Estimation(r);
      ctrnn_output[r][0] = m_agents[r]->Agent_Believe;
    }
    if (m_parameters->isModeEvaluation())
    {
      all_opinions[r][m_iteration] = round(ctrnn_output[r][0]);
    }
    if (m_parameters->isModeViewing())
    {
      colour.assign(3, round(ctrnn_output[r][0]));
      m_agents[r]->set_colour(colour);
    }
  }
}

/* ----------------------------------------------------------------------------------- */

void Ahmed_experiment::update_actuators(void)
{
  for (int r = 0; r < m_agents.size(); r++)
  {
    // update robot wheels velocity
    m_agents[r]->set_vel(outputs[r]);
  }
}

/* ----------------------------------------------------------------------------------- */

void Ahmed_experiment::update_world(void)
{
  for (int r = 0; r < m_agents.size(); r++)
  {
    // update robot position and rotation
    m_agents[r]->update_pos_rot();
  }
}

/* ----------------------------------------------------------------------------------- */
void Ahmed_experiment::compute_fitness(void)
{
  if (m_iteration > (m_parameters->getNbMaxIterations() * 0.5))
  {
    if (floor_type == WHITE_DOMINANT)
    {
      for (int r = 0; r < m_agents.size(); r++)
        m_local_fitness[r] += ctrnn_output[r][0];
    }
    else
    {
      for (int r = 0; r < m_agents.size(); r++)
        m_local_fitness[r] += 1.0 - ctrnn_output[r][0];
    }
  }

  if (m_parameters->isModeEvaluation())
  {
    if (m_iteration == (m_parameters->getNbMaxIterations() - 1))
    {
      for (int r = 0; r < m_agents.size(); r++)
        if (round(ctrnn_output[r][0]) == floor_type)
          CountofRightAgents++;
      CountVec.push_back(CountofRightAgents);
    }
  }
}

/* ----------------------------------------------------------------------------------- */
// This function is called at the end of each evaluation
void Ahmed_experiment::finalise_single_evaluation(void)
{
  double tmp_var = 0.0;
  for (int r = 0; r < m_agents.size(); r++)
  {
    tmp_var += ((double)(m_local_fitness[r] / (m_parameters->getNbMaxIterations() * 0.5)));
  }
  m_fitness[0] += tmp_var / (double)(m_agents.size());
  if (m_parameters->isModeEvaluation())
    Evaluation_statistics();
}

/* ----------------------------------------------------------------------------------- */
// This function is called at the end of all evaluations
void Ahmed_experiment::finalise_evaluation_loop(void)
{
  m_fitness[0] /= (double)(m_parameters->getNbMaxEvaluations());
  if (m_parameters->isModeViewing())
    cout << m_fitness[0] << endl;

  if (m_parameters->isModeEvaluation())
  {
    Analyse_BestOne();
  }
}

/* ----------------------------------------------------------------------------------- */
void Ahmed_experiment::Evaluation_statistics(void)
{

  if (m_evaluation % 2)
  {
    calculate_change_summary(Data_Summary_White);
  }

  else
  {
    calculate_change_summary(Data_Summary_Black);
  }
}

/* ----------------------------------------------------------------------------------- */
void Ahmed_experiment::Choose_BestOne_BestGenotypes(void)
{
  ofstream BestOneWhite, BestOneBlack;
  BestOneWhite.open("../ReEvaluation/BestOneWhite.csv", ios::app);
  BestOneBlack.open("../ReEvaluation/BestOneBlack.csv", ios::app);

  for (size_t i = 0; i < CountVec.size(); i++)
  {
    if (i % 2)
    {
      BestOneWhite << m_parameters->getRunName().c_str() << "," << m_parameters->getRootSeed() << ","
                   << m_parameters->getGenerationStart() << ","
                   << "WhiteDominant"
                   << "," << m_fitness[0] << ","
                   << CountVec[i]
                   << endl;
    }
    else
    {
      BestOneBlack << m_parameters->getRunName().c_str() << "," << m_parameters->getRootSeed() << ","
                   << m_parameters->getGenerationStart() << ","
                   << "BlackDominant"
                   << "," << m_fitness[0] << ","
                   << 20 - CountVec[i]
                   << endl;
    }
  }
}

/* ----------------------------------------------------------------------------------- */
void Ahmed_experiment::Analyse_BestOne(void)
{
  ofstream BestOneWhiteDetails, BestOneBlackDetails, Visited_Tiles;

  BestOneBlackDetails.open("../ReEvaluation/BD_50cm.csv", ios::app);
  BestOneWhiteDetails.open("../ReEvaluation/WD_50cm.csv", ios::app);
  for (size_t i = 0; i < CountVec.size(); i++)
  {
    if (i % 2)
    {
      BestOneWhiteDetails << m_parameters->getRootSeed() << ",";
      int found1 = 0;
      int found2 = 0;
      for (int j = 0; j < Data_Summary_White.size(); j++)
      {
        BestOneWhiteDetails << Data_Summary_White[j] << ",";
        if (j > 2 && j < Data_Summary_White.size() - 1 && !found1)
          if (Data_Summary_White[j] == m_agents.size() && Data_Summary_White[j + 1] == m_agents.size())
            found1 = j;
        if (j > 2 && j < Data_Summary_White.size() - 1 && !found2)
          if (Data_Summary_White[j] == 0 && Data_Summary_White[j + 1] == 0)
            found2 = j;
      }
      BestOneWhiteDetails << found1 * register_data_time / 10 << ",";
      BestOneWhiteDetails << found2 * register_data_time / 10;
      BestOneWhiteDetails << endl;
      // }
    }
    else
    {
      int found1 = 0;
      int found2 = 0;
      BestOneBlackDetails << m_parameters->getRootSeed() << ",";
      for (int j = 0; j < Data_Summary_Black.size(); j++)
      {
        BestOneBlackDetails << Data_Summary_Black[j] << ",";
        if (j > 2 && j < Data_Summary_Black.size() - 1 && !found1)
          if (Data_Summary_Black[j] == m_agents.size() && Data_Summary_Black[j + 1] == m_agents.size())
            found1 = j;
        if (j > 2 && j < Data_Summary_Black.size() - 1 && !found2)
          if (Data_Summary_Black[j] == 0 && Data_Summary_Black[j + 1] == 0)
            found2 = j;
      }
      BestOneBlackDetails << found1 * register_data_time / 10 << ",";
      BestOneBlackDetails << found2 * register_data_time / 10;
      BestOneBlackDetails << endl;
    }
  }
}

/* ----------------------------------------------------------------------------------- */
void Ahmed_experiment::calculate_change_summary(vector<int> &vec)
{
  int interval_step = register_data_time;
  int interval_begin = 0;
  int interval_end = m_parameters->getNbMaxIterations();
  vector<int> longestT, longestF;
  vector<int> RCount;
  vector<int> ChangeC;
  vector<int> RobotCount;
  int sum = 0, RTCount = 0, RFCount = 0, ROCount = 0;
  int count = 0;
  int RightOpinionCount = 0;
  int long_countT = 0, long_countF = 0;
  for (size_t x = interval_begin; x < interval_end; x += interval_step)
  {
    RightOpinionCount = 0;
    sum = 0;
    RTCount = 0;
    RCount.clear();
    for (int r = 0; r < all_opinions.size(); r++)
    {
      count = 0;
      for (int j = x; j < x + interval_step - 1; j++)
      {
        if (all_opinions[r][j] != all_opinions[r][j + 1])
          count++;
      }
      if (all_opinions[r][x] == floor_type)
        RightOpinionCount++;
      if (count == 0 && all_opinions[r][x + interval_step - 2] == floor_type)
        count = 0;
      else if (count == 0 && all_opinions[r][x + interval_step - 2] != floor_type)
        count = -1;
      RCount.push_back(count);
    }

    RobotCount.push_back(RightOpinionCount);
  }
  for (size_t i = 0; i < RobotCount.size(); i++)
  {
    vec.push_back(RobotCount[i]);
  }
}

//  /* ----------------------------------------------------------------------------------- */

bool Ahmed_experiment::stop_iterations_loop(void)
{
  if (m_iteration >= m_parameters->getNbMaxIterations())
  {
    finalise_single_evaluation();
    m_iteration = 0;
    if (m_parameters->isModeEvolution() || m_parameters->isModeEvaluation())
    {
      return false;
    }
    else if (m_parameters->isModeViewing())
    {
      if (stop_evaluations_loop())
      {
        return true;
      }
      else
      {
        return false;
      }
    }
  }
  else
  {
    return true;
  }
  // return true;
  return true;
}

/* ----------------------------------------------------------------------------------- */

bool Ahmed_experiment::stop_evaluations_loop(void)
{
  m_evaluation++;
  if (m_parameters->isModeEvolution())
  {
    if (m_evaluation >= m_parameters->getNbMaxEvaluations())
    {
      m_evaluation = 0;
      finalise_evaluation_loop();
      return false;
    }
    else
      return true;
  }
  else if (m_parameters->isModeViewing())
  {
    if (m_evaluation >= m_parameters->getNbMaxEvaluations())
    {
      m_evaluation = 0;
      finalise_evaluation_loop();
      exit(0);
      init_evaluations_loop();
      return false;
    }
    else
    {
      init_single_evaluation();
      return true;
    }
  }
  else if (m_parameters->isModeEvaluation())
  {
    if (m_evaluation >= m_parameters->getNbMaxEvaluations())
    {
      m_evaluation = 0;
      finalise_evaluation_loop();
      return false;
    }
    else
    {
      return true;
    }
  }
}

/* ----------------------------------------------------------------------------------- */

/* ----------------------------------------------------------------------------------- */
//
void Ahmed_experiment::Initial_Hand_Coded_Model(void)
{
  for (size_t i = 0; i < m_agents.size(); i++)
  {
    m_agents[i]->Agent_State = EXPLORATION;
    m_agents[i]->Exploration_Time = round(gsl_ran_exponential(GSL_randon_generator::r_rand, Median));
    m_agents[i]->Duration = 0;
    m_agents[i]->Dissemination_Time = 0;
    m_agents[i]->Believe_Count = 0;
    if (i < m_agents.size() / 2)
    {
      m_agents[i]->Agent_Believe = BLACK_DOMINANT;
    }
    else
    {
      m_agents[i]->Agent_Believe = WHITE_DOMINANT;
    }
    m_agents[i]->Neighbours_ID.clear();
  }
}

/* ----------------------------------------------------------------------------------- */
// this function used in the exploration mode of hand coded solutions.
void Ahmed_experiment::Exploration(int r)
{
  if (m_agents[r]->Exploration_Time <= 0)
  {
    if (m_agents[r]->Duration > 0)
    {
      m_agents[r]->Agent_State = DISSEMINATION;
      m_agents[r]->Dissemination_Time = round(gsl_ran_exponential(GSL_randon_generator::r_rand, Median) * (m_agents[r]->Believe_Count / (m_agents[r]->Duration)));
    }
    else
    {
      m_agents[r]->Exploration_Time = round(gsl_ran_exponential(GSL_randon_generator::r_rand, Median));
    }
    m_agents[r]->Believe_Count = 0;
    m_agents[r]->Duration = 0;
    return;
  }
  if (m_agents[r]->Agent_Believe == floor_sensor_readings[r][0])
    m_agents[r]->Believe_Count++;
  m_agents[r]->Exploration_Time--;
  m_agents[r]->Duration++;
}

/* ----------------------------------------------------------------------------------- */
// this function used in the exploration mode of hand coded solutions.
void Ahmed_experiment::Dissemination(int r)
{
  if (m_agents[r]->Dissemination_Time <= 0)
  {
    m_agents[r]->Agent_State = ESTIMATION;
    return;
  }
  if (m_agents[r]->Dissemination_Time <= ListeningTime) // if we are in the last 2 seconds of the dissemination period collect the neighbours opinions
  {
    m_agents[r]->Dist_W_AllRobot.clear(); // first value represents the distance between the r and t robots 2nd value is the robot ID
    for (int t = 0; t < m_agents.size(); t++)
    {
      if (t != r)
        m_agents[r]->Dist_W_AllRobot.push_back(make_pair(m_robot_robot_distance[r][t], t));
    }

    for (size_t i = 0; i < m_agents[r]->Dist_W_AllRobot.size(); i++) // check the list of neighbours with respect to comm. distance and agent state
    {
      // if (m_agents[r]->Neighbours_ID.size() <= K_Neighbours && m_agents[ m_agents[r]->dist_vect_myneighbor[i].second]->Agent_State == DISSEMINATION)
      if (m_agents[r]->Dist_W_AllRobot[i].first <= Comm_Distance && m_agents[m_agents[r]->Dist_W_AllRobot[i].second]->Agent_State == DISSEMINATION)
      {
        if (!m_agents[r]->Neighbours_ID.empty()) // if this is not the first neighbour, check if this neighbour exist or not within neighbours list
        {                                        // if yes, update the opinion, if no add the neighbour with its opinion to the list.
          for (size_t j = 0; j < m_agents[r]->Neighbours_ID.size() /*&& !m_agents[r]->found*/; j++)
          {
            if (m_agents[r]->Neighbours_ID[j].first == m_agents[r]->Dist_W_AllRobot[i].second)
            {
              m_agents[r]->Neighbours_ID.erase(m_agents[r]->Neighbours_ID.begin() + j);
            }
          }
          m_agents[r]->Neighbours_ID.push_back(make_pair(m_agents[r]->Dist_W_AllRobot[i].second, m_agents[m_agents[r]->Dist_W_AllRobot[i].second]->Agent_Believe));
        }
        else
          m_agents[r]->Neighbours_ID.push_back(make_pair(m_agents[r]->Dist_W_AllRobot[i].second, m_agents[m_agents[r]->Dist_W_AllRobot[i].second]->Agent_Believe));
      }
    }
  }
  m_agents[r]->Dissemination_Time--;
}

/* ----------------------------------------------------------------------------------- */
// this function used in the exploration mode of hand coded solutions.
// time to reconsider the agent believe
void Ahmed_experiment::Estimation(int r)
{
  if (!m_agents[r]->Neighbours_ID.empty())
  {
    if (Strategy == VM)
    {
      VM_CDM_S(r);
    }
    else if (Strategy == MM)
    {
      MM_CDM_S(r);
    }
  }
  m_agents[r]->Neighbours_ID.clear();
  m_agents[r]->Agent_State = EXPLORATION;
  m_agents[r]->Exploration_Time = round(gsl_ran_exponential(GSL_randon_generator::r_rand, Median));
}
/* ----------------------------------------------------------------------------------- */
void Ahmed_experiment::VM_CDM_S(int r)
{
  // if the list of neighbours contains one neighbour only, adopt the opinion of this neighbour
  if (m_agents[r]->Neighbours_ID.size() == 1)
  {
    m_agents[r]->Agent_Believe = m_agents[r]->Neighbours_ID[0].second;
  }
  else
  { // if the list of neighbours contains more than one neighbour, adopt an opinion randomly from the last two neighbours
    m_agents[r]->Agent_Believe = m_agents[r]->Neighbours_ID[(m_agents[r]->Neighbours_ID.size() - 1) - gsl_rng_uniform_int(GSL_randon_generator::r_rand, 2)].second;
  }
}

/* ----------------------------------------------------------------------------------- */

void Ahmed_experiment::MM_CDM_S(int r)
{
  m_agents[r]->BCount = 0;
  m_agents[r]->WCount = 0;
  // add the self opinion to the list of the neighbours opinion
  m_agents[r]->Neighbours_ID.push_back(make_pair(r, m_agents[r]->Agent_Believe));
  // count the number of robots that hold BD opinion and number of robot that hold WD opinion
  for (size_t i = 0; i < m_agents[r]->Neighbours_ID.size(); i++)
  {
    if (m_agents[m_agents[r]->Neighbours_ID[i].first]->Agent_Believe == BLACK_DOMINANT)
      m_agents[r]->BCount++;
    else if (m_agents[m_agents[r]->Neighbours_ID[i].first]->Agent_Believe == WHITE_DOMINANT)
      m_agents[r]->WCount++;
  }
  // adopt the opinion of the majority
  if (m_agents[r]->BCount > m_agents[r]->WCount)
    m_agents[r]->Agent_Believe = BLACK_DOMINANT;
  else if (m_agents[r]->WCount > m_agents[r]->BCount)
    m_agents[r]->Agent_Believe = WHITE_DOMINANT;
}
#endif