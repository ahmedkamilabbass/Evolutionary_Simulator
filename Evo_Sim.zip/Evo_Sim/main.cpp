#include "./MISC/parameters.h"
#include "./EXP/experiment.h"

#ifdef _BULLET_WORLD_
#include "./EXP/first_exp.h"
#else
#include "./EXP/ahmed_exp.h"
#endif

#ifdef _GRAPHICS_

#include "./RENDERING/viewer.h"
#include "./RENDERING/interface.h"

#endif

int main(int argc, char **argv) {
    NbTotProcesses = 8;
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &NbRank);
    MPI_Comm_size(MPI_COMM_WORLD, &NbTotProcesses);

    //parse the command line
    Parameters *parameters = new Parameters(argc, argv);

    //Init the Experiment
    std::vector<Experiment *> exp;
#ifdef _BULLET_WORLD_
    exp.push_back( new First_experiment ( parameters ) );
#else
    exp.push_back(new Ahmed_experiment(parameters));
#endif

    //Evolutionary mode
    if (parameters->isModeEvolution()) {
        while (parameters->getCurrentGeneration() < parameters->getNbMaxGenerations()) {
            //if(NbRank == 0){
            //cerr << " Generation = " << parameters->getCurrentGeneration() << endl;
            //getchar();
            //}
            exp[0]->runOneGeneration();
            parameters->increment_current_generation();
        }
    }
        //Viewing mode
    else if (parameters->isModeViewing()) {
#ifdef _GRAPHICS_
        QApplication application(argc, argv);
        Viewer *viewer = new Viewer(0, exp[0], argc, argv);
        Interface *render = new Interface(0, exp[0], viewer);
        render->show();
        return application.exec();
        delete viewer;
        delete render;
#endif
    }
    //Evaluation mode
    else if (parameters->isModeEvaluation()) {
      
      char *buffer_file = new char[500];
      for(int generation = parameters->getGenerationStart();
	  generation >= parameters->getGenerationEnd(); generation-=1){

	//Choose which file name
	sprintf(buffer_file, "%s%s0_pop_G%d.geno", parameters->getGenomeFileDir().c_str(), parameters->getRunName().c_str(), generation );
	
	
	//Load the genes into the file "genes"
	int which_genotypes = 0;//This is the genotype number; usually it is the best, that is number 0
	int num_groups;
	vector < vector <chromosome_type> > genes;
	upload_genome_from_file <chromosome_type> ( buffer_file, genes, &num_groups );
	exp[0]->from_genome_to_controllers( genes, which_genotypes );
	//cerr << " " << buffer_file << endl; 
        exp[0]->evaluate_solutions();
      }
      delete[] buffer_file;
    }

    for (int i = 0; i < exp.size(); i++)
        delete exp[i];
    exp.clear();


    delete parameters;
    MPI_Finalize();

    std::cout << " Rank = " << NbRank << " Programm End..." << std::endl;
    return 0;
}
